from chatbot.model import MenstrualHealthChatbot

def main():
    print("Welcome to the Menstrual Health Equity Chatbot!")
    print("Type 'exit' to quit.\n")

    chatbot = MenstrualHealthChatbot()

    while True:
        user_input = input("You: ").strip()
        if user_input.lower() in ['exit', 'quit']:
            print("Thank you for using the chatbot. Goodbye!")
            break
        response = chatbot.get_response(user_input)
        print(f"Bot: {response}\n")

if __name__ == "__main__":
    main()

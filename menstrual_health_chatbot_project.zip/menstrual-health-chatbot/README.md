# Menstrual Health Equity Chatbot

An AI chatbot powered by open-source Large Language Models (LLMs) to provide personalized, multilingual menstrual health education tailored to diverse socioeconomic contexts and linguistic backgrounds.

---

## Features

- Multilingual support with dialect considerations (English, Spanish sample)
- Socioeconomic context adaptation for educational content
- Basic bias mitigation module to reduce misinformation and stereotypes
- Modular design for easy expansion and integration with real LLM APIs
- Command-line interface demo

---

## Setup

1. Create and activate a Python environment (recommended).
2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Run the chatbot:

```bash
python main.py
```

---

## Project Structure

- `chatbot/model.py`: Mock LLM interaction and AI integration
- `chatbot/bias_mitigation.py`: Simple bias detection and filtering
- `chatbot/multilingual_support.py`: Language/dialect processing
- `chatbot/socio_context.py`: Adapts responses based on socioeconomic data
- `chatbot/data/`: Contains FAQs and socioeconomic info JSON files
- `main.py`: CLI interface to interact with the chatbot

---

## Future Improvements

- Integrate real LLM APIs (OpenAI, Huggingface)
- Add more languages and dialects
- Use human feedback loop for system evaluation
- Expand bias mitigation with advanced techniques
- Web or mobile front-end integration

---

## License

MIT License

---

## Contact

Developed by [Your Name] — Open for collaboration and improvements.

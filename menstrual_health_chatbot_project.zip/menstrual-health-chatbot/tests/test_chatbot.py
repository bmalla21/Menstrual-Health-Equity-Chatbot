from chatbot.model import MenstrualHealthChatbot

def test_english_faq():
    bot = MenstrualHealthChatbot()
    question = "What is menstruation?"
    response = bot.get_response(question)
    assert "uterus sheds" in response.lower()

def test_spanish_faq():
    bot = MenstrualHealthChatbot()
    question = "¿Qué es la menstruación?"
    response = bot.get_response(question)
    assert "útero elimina" in response.lower()

def test_socio_context():
    bot = MenstrualHealthChatbot()
    question = "I am from a low income rural area"
    response = bot.get_response(question)
    assert "low-income" in response.lower() or "limited" in response.lower()

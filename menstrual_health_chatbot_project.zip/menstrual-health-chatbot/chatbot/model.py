import json
from .bias_mitigation import filter_biases
from .multilingual_support import detect_language, translate_to_english, translate_from_english
from .socio_context import analyze_socioeconomic_context

class MenstrualHealthChatbot:
    def __init__(self):
        # Load multilingual FAQs
        with open('chatbot/data/menstrual_faq_en.json', 'r', encoding='utf-8') as f:
            self.faq_en = json.load(f)
        with open('chatbot/data/menstrual_faq_es.json', 'r', encoding='utf-8') as f:
            self.faq_es = json.load(f)
        with open('chatbot/data/socio_context_info.json', 'r', encoding='utf-8') as f:
            self.socio_info = json.load(f)

    def get_response(self, user_input):
        lang = detect_language(user_input)
        print(f"[DEBUG] Detected language: {lang}")

        # Translate to English for uniform processing if not English
        if lang != 'en':
            user_input_en = translate_to_english(user_input, lang)
        else:
            user_input_en = user_input

        # Analyze socioeconomic context keywords in user input
        context = analyze_socioeconomic_context(user_input_en, self.socio_info)
        print(f"[DEBUG] Detected socioeconomic context: {context}")

        # Simple FAQ matching (mock)
        answer = self.match_faq(user_input_en, lang, context)

        # Bias mitigation filtering
        filtered_answer = filter_biases(answer)

        # Translate answer back if needed
        if lang != 'en':
            filtered_answer = translate_from_english(filtered_answer, lang)

        return filtered_answer

    def match_faq(self, question, lang, context):
        # Basic keyword matching demo, extend with NLP similarity etc.
        faqs = self.faq_en if lang == 'en' else self.faq_es

        for q, a in faqs.items():
            if q.lower() in question.lower():
                # Append context info for educational tailoring
                context_note = self.socio_info.get(context, "")
                return f"{a} \n\nNote: {context_note}"
        return "I'm sorry, I don't have information on that topic yet. Please ask something else."

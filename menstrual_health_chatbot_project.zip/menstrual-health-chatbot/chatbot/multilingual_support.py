def detect_language(text):
    # Very simple language detection demo
    if any(word in text.lower() for word in ['el', 'la', 'periodo', 'menstruación']):
        return 'es'
    return 'en'

def translate_to_english(text, source_lang):
    # Mock translation
    translations = {
        "¿qué es la menstruación?": "what is menstruation?",
        "¿cómo manejar el dolor menstrual?": "how to manage menstrual pain?"
    }
    return translations.get(text.lower(), text)

def translate_from_english(text, target_lang):
    # Mock reverse translation
    reverse_translations = {
        "what is menstruation?": "¿qué es la menstruación?",
        "how to manage menstrual pain?": "¿cómo manejar el dolor menstrual?"
    }
    return reverse_translations.get(text.lower(), text)

def filter_biases(text):
    # Mock bias mitigation by removing stereotypes or misinformation (simple demo)
    bias_phrases = [
        "women are weak", "periods are dirty", "can't work during period"
    ]
    for phrase in bias_phrases:
        if phrase in text.lower():
            text = text.lower().replace(phrase, "[content removed due to bias]")
    return text

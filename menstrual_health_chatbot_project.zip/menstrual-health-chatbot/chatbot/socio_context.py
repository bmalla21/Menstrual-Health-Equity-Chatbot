def analyze_socioeconomic_context(text, context_data):
    # Simple keyword-based socioeconomic context detection
    low_income_keywords = ['low income', 'poor', 'rural', 'limited access', 'no money']
    mid_income_keywords = ['middle class', 'average income', 'urban', 'working class']
    high_income_keywords = ['wealthy', 'high income', 'affluent', 'professional']

    text_lower = text.lower()

    if any(word in text_lower for word in low_income_keywords):
        return 'low_income'
    elif any(word in text_lower for word in mid_income_keywords):
        return 'mid_income'
    elif any(word in text_lower for word in high_income_keywords):
        return 'high_income'
    else:
        return 'general'
